import logo from './cup.svg';
import './App.css';
import React, { useState } from 'react';
import { Container, Nav, Row, Col, Card, CardDeck, Carousel, Form, Button, FormGroup, Image } from 'react-bootstrap';
import {
  BrowserRouter as Router,
  Switch,
  Route,
  Link
} from "react-router-dom";
import { Cup } from 'react-bootstrap-icons';




function App() {

  return (
    <Router>
      <Container>
        <Cup id="cup" height="50px" width="50px"></Cup>
        <Nav id="hauptmenu" className="justify-content-center mt-4 mb-4" defaultActiveKey="/home">
          <Nav.Item >
            <Nav.Link className="navlink" href="/startseite">Startseite</Nav.Link>
          </Nav.Item>
          <Nav.Item>
            <Nav.Link className="navlink" href="/shop">Shop</Nav.Link>
          </Nav.Item>
          <Nav.Item>
            <Nav.Link className="navlink" href="/uns">Über uns</Nav.Link>
          </Nav.Item>
        </Nav>

        <Switch>
          <Route exact path="/startseite">
            <Startseite />
          </Route>
          <Route path="/shop">
            <Shop />
          </Route>
          <Route path="/uns">
            <Uns />
          </Route>
          <Route path="/minztee">
            <Minztee />
          </Route>
        </Switch>


      </Container>
    </Router>
  );
}

export default App;

function Startseite() {
  return (
    <Image src="1.png" fluid />
  );
}

function Shop() {
  return (
    <CardDeck>
      <Card>
        <Card.Img variant="top" src="1.png" />
        <Card.ImgOverlay>
          <Card.Title className="titleproduct"></Card.Title>
        </Card.ImgOverlay>
        <Card.Body>
          <Card.Title><h3>Preis:</h3> <br />
            <p class="productprice"> klein. 5.95 Fr. </p> <br />
            <p class="productprice">gross. 7.95 Fr. </p>
          </Card.Title>
          <Card.Text>

          </Card.Text>
          <Row>
            <Col></Col>
            <Col></Col>
            <Col></Col>
            <Col>
              <Button variant="outline-dark" class="buttonshop" href="/minztee">Kaufen</Button>
            </Col>
          </Row>
        </Card.Body>
        <Card.Footer>
          <small className="text-muted">Erstellt von WinTea</small>
        </Card.Footer>
      </Card>
      <Card>
        <Card.Img variant="top" src="2.png" />
        <Card.ImgOverlay>
          <Card.Title className="titleproduct"></Card.Title>
        </Card.ImgOverlay>
        <Card.Body>
          <Card.Title><h3>Preis:</h3> <br />
            <p class="productprice"> klein. 6.95 Fr. </p> <br />
            <p class="productprice">gross. 8.95 Fr. </p>
          </Card.Title>
          <Card.Text>

          </Card.Text>
          <Row>
            <Col></Col>
            <Col></Col>
            <Col></Col>
            <Col>
              <Button variant="outline-dark" class="buttonshop" href="/minztee">Kaufen</Button>
            </Col>
          </Row>
        </Card.Body>
        <Card.Footer>
          <small className="text-muted">Erstellt von WinTea</small>
        </Card.Footer>
      </Card>
    </CardDeck>
  );
}

function Uns() {
  return (
    <h1>In Bearbeitung</h1>
    /*
    <Carousel>
      <Carousel.Item>
        <img
          className="d-block w-100"
          src="hintergrund.jpg"
          alt="First slide"
        />
        <Carousel.Caption>
          <h3>First slide label</h3>
          <p>Nulla vitae elit libero, a pharetra augue mollis interdum.</p>
        </Carousel.Caption>
      </Carousel.Item>
      <Carousel.Item>
        <img
          className="d-block w-100"
          src="hintergrund.jpg"
          alt="Third slide"
        />

        <Carousel.Caption>
          <h3>Second slide label</h3>
          <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
        </Carousel.Caption>
      </Carousel.Item>
      <Carousel.Item>
        <img
          className="d-block w-100"
          src="hintergrund.jpg"
          alt="Third slide"
        />

        <Carousel.Caption>
          <h3>Third slide label</h3>
          <p>Praesent commodo cursus magna, vel scelerisque nisl consectetur.</p>
        </Carousel.Caption>
      </Carousel.Item>
    </Carousel>
    */
  );
}

function Minztee() {
  return (
    <Row>
      <Col></Col>
      <Col>
        <Image src="TwintQRCode.PNG" rounded height="400px" width="300px" id="QRCode" />
      </Col>
      <Col></Col>
    </Row>


  );
}